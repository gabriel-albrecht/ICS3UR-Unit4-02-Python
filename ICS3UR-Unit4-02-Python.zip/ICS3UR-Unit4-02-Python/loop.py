#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This program calculates factorials


def main():
    # this function uses a while loop
    loop = 1
    summ = 1

    try:
        # input
        im = int(input("Enter a positive integer: "))
        print("")

    # process & output
        if im >= 0:
            if im != 0:
                while loop <= im:
                    summ = summ * loop
                    loop = loop + 1
                print("{0}! is {1}".format(im, summ))
            else:
                print("0! is 1")
        else:
            print("That is a negative integer.")

    except ValueError:
        print("")
        print("That is not an integer.")


if __name__ == "__main__":
    main()
